function copyText(id, btn) {
    const text = document.getElementById(id).innerText;
    navigator.clipboard.writeText(text);

    const original = btn.innerText;
    btn.innerText = "Copied ✓";
    btn.classList.add("copied");

    setTimeout(() => {
        btn.innerText = original;
        btn.classList.remove("copied");
    }, 1500);
}
